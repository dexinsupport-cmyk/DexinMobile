# Dexin Mobile

لانچر/کلاینت موبایل دکسین موبایل با یک سرور ثابت:

- Server: `5.57.37.215:7777`
- App name: `Dexin Mobile`
- Game download URL: `https://DexinMobile.ir/game.zip`

## مهم: فایل بازی

فایل `game.zip` باید روی آدرس بالا قرار بگیرد. دانلودر فعلی از `HEAD` و `Range` استفاده می‌کند، بنابراین هاست باید `Content-Length` و دانلود تکه‌ای (`Range: bytes=...`) را پشتیبانی کند.

## ساخت APK با GitHub Actions

1. این پروژه را داخل یک Repository عمومی GitHub آپلود کنید.
2. وارد **Actions** شوید.
3. Workflow با نام **Build Dexin Mobile APK** را باز کنید.
4. روی **Run workflow** بزنید.
5. بعد از سبز شدن Build، از بخش **Artifacts** فایل `DexinMobile-debug-apk` را دانلود کنید.

> این Build از Android Studio استفاده نمی‌کند؛ GitHub Actions محیط Java و Android SDK را خودش آماده می‌کند.

### اگر آدرس فایل بازی شما فرق دارد
فقط مقدار `GAME_DOWNLOAD_URL` در فایل زیر را تغییر دهید:
`app/src/main/java/com/mihanrp/sa/jsonenter/PublicInfo.java`
