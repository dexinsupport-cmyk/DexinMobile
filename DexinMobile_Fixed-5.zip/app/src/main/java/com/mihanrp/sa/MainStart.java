package com.mihanrp.sa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.mihanrp.sa.function.CheckLoadingFiles;
import com.mihanrp.sa.function.SendPostRequest;
import com.mihanrp.sa.jsonenter.PublicInfo;
import com.mihanrp.core.R;

import org.ini4j.Wini;

import java.io.File;
import java.io.IOException;

import com.mihanrp.sa.function.BaseActivity;


public class MainStart extends BaseActivity {
    int gg = 0;
    boolean bOnce = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_start);

        int mod_int = 0;
        try {
            mod_int = CheckLoadingFiles.getModsID();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(mod_int == 0) PublicInfo.GTAmods = 0;
        else {
            try {
                if(CheckLoadingFiles.getMods(mod_int)){
                    PublicInfo.GTAmods = 1;
                } else PublicInfo.GTAmods = 0;
            } catch (IOException e) {
                e.printStackTrace();
                PublicInfo.GTAmods = 0;
            }

        }
        if (!bOnce) {
            bOnce = true;
            String GetLogPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/" + "MihanLog";
            String GetFileLogPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/MihanLog/logcat.txt";
            try {
                if (!new File(GetLogPath).exists()) {
                    new File(GetLogPath).mkdirs();
                }
                File file = new File(GetFileLogPath);
                if (file.exists()) {
                    file.delete();
                }
                file.createNewFile();
                Runtime runtime = Runtime.getRuntime();
                runtime.exec("logcat -f " + file.getAbsolutePath());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("**** Loading MainStart");
        if(gg == 0) {
            gg = 1;
            finish();

            Intent intent = new Intent(MainStart.this, com.mihanrp.core.GTASA.class);
            intent.putExtras(getIntent());

            startActivity(intent);
            overridePendingTransition(0, 0);
        }
        else {
            Toast toast = Toast.makeText(getApplicationContext(),
                    "Game launch 2 times!",
                    Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
            System.out.println("Mikhail 2 launch!!!");
        }
        finish();
    }
}