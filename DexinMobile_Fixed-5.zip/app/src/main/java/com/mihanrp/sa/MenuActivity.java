package com.mihanrp.sa;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.mihanrp.core.R;
import com.mihanrp.sa.function.BaseActivity;
import com.mihanrp.sa.function.CheckLoadingFiles;
import com.mihanrp.sa.function.MainDialogFragment;
import com.mihanrp.sa.function.ReadNick;
import com.mihanrp.sa.jsonenter.ReadMonitoring;
import com.mihanrp.sa.jsonenter.PublicInfo;
import com.mihanrp.sa.model.NewsModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.ini4j.Wini;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import cz.msebera.android.httpclient.Header;

public class MenuActivity extends BaseActivity {

    // ----- ثابت‌ها -----
    private static final String APP_PREFERENCES = "settings_app";
    private static final String APP_PREFERENCES_DIALOG = "DialogStart";

    private static final int MY_PERMISSIONS_RECORD_AUDIO = 1;
    private static final long MONITOR_INTERVAL_MS = 0L;

    // ----- فیلد‌ها -----
    private String nickName;
    private EditText editTextName;

    private TextView textViewServerCount;
    private ProgressBar progressBarServer;

    private SharedPreferences mSettings;

    public static List<NewsModel> itemsNews;
    public static List<File> listOfFiles = new ArrayList<>();

    private View startGameView;
    private int saveButtonPressing = 0;

    private static final Random RANDOM = new Random();

    // ----- چرخه حیات -----
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        mSettings = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);

        initViews();
        setupListeners();
        applyInitialState();

        // بررسی آرگومان اینتنت (درخواست شروع بازی از خارج)
        Intent intent = getIntent();
        boolean startGame = intent.getBooleanExtra("startGame", false);
        int typeStart = intent.getIntExtra("typeStart", 1);
        if (startGame) {
            requestAudioPermissions(typeStart);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // شروع درخواست دوره‌ای
        // Single fixed server: no external test/monitor API.
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        // جلوگیری از خروج با دکمه back
    }

    // ----- مقداردهی اولیه ویوها -----
    private void initViews() {
        TextView infoVersionApp = findViewById(R.id.textViewVersion);
        infoVersionApp.setText(PublicInfo.VersionNameAppStatic);

        progressBarServer = findViewById(R.id.progressBarServer);
        textViewServerCount = findViewById(R.id.textViewServerCount);

        TextView textViewWelcomePlayer = findViewById(R.id.textViewWelcomePlayer);
        ReadNick.show(textViewWelcomePlayer);

        editTextName = findViewById(R.id.homeEditTextChangeName);

        ImageView imageViewContactForm = findViewById(R.id.imageViewContactForm);
        imageViewContactForm.setClickable(true);

        TextView imageDownLeftMenu = findViewById(R.id.imageDownLeftMenu);
        imageDownLeftMenu.setClickable(true);

        FloatingActionButton imageDownCenterMenu = findViewById(R.id.imageDownCenterMenu);
        imageDownCenterMenu.setClickable(true);

        ImageView imageViewSaveNick = findViewById(R.id.homeImageViewSaveNick);
        imageViewSaveNick.setClickable(true);

        // نمایش لاگ تاریخ برای دیباگ
        Date dateNow = new Date();
        SimpleDateFormat formatForDateNow = new SimpleDateFormat("dd.MM.yyyy");
        System.out.println("MIHAIL Current date " + formatForDateNow.format(dateNow));
    }

    // ----- اتصال Listener‌ها -----
    private void setupListeners() {
        final Animation animClick = AnimationUtils.loadAnimation(this, R.anim.click);

        findViewById(R.id.imageViewContactForm).setOnClickListener(v -> {
            v.startAnimation(animClick);
            startActivity(new Intent(MenuActivity.this, ContactActivity.class));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.imageDownLeftMenu).setOnClickListener(v -> {
            v.startAnimation(animClick);
            startActivity(new Intent(MenuActivity.this, SetingsActivity.class));
            overridePendingTransition(0, 0);
        });

        FloatingActionButton fab = findViewById(R.id.imageDownCenterMenu);
        fab.setOnClickListener(v -> {
            startGameView = v;
            saveButtonPressing = 1;
            requestAudioPermissions(1);
        });

        fab.setOnLongClickListener(v -> {
            saveButtonPressing = 2;
            requestAudioPermissions(2);
            // return true if we consumed the event
            return true;
        });

        // ذخیره نام کاربری
        findViewById(R.id.homeImageViewSaveNick).setOnClickListener(v -> {
            try {
                saveNick();
            } catch (IOException e) {
                e.printStackTrace();
                recreate();
            }
        });
    }

    // ----- وضعیت اولیه -----
    private void applyInitialState() {
        OpenDialogIfNeeded();
        updateFixedServerCard();

        if (PublicInfo.successInstallApk) {
            PublicInfo.successInstallApk = false;
            new MainDialogFragment(
                    "نصب کامل شد!",
                    "از انتخاب پروژه دکسین موبایل از شما متشکریم!",
                    "بستن",
                    null,
                    null,
                    null
            ).show(getSupportFragmentManager(), "installDone");
        }

        try {
            openNick();
            if (nickName != null && !nickName.equals("Nick_Name")) {
                editTextName.setText(nickName);
                editTextName.setSelection(editTextName.getText().length());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ----- مجوز‌ها -----
    private void requestAudioPermissions(int typeStart) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
                new AlertDialog.Builder(this)
                        .setTitle("اجازه دسترسی به میکروفون")
                        .setMessage("شما اجازه دسترسی ندارید، با کلیک روی دکمه زیر، دسترسی را مجاز کنید.\n\nدر غیر این صورت، بدون این اجازه، بازی ممکن است از کار بیفتد.")
                        .setPositiveButton("به تنظیمات بروید", (dialog, which) ->
                                ActivityCompat.requestPermissions(MenuActivity.this,
                                        new String[]{Manifest.permission.RECORD_AUDIO},
                                        MY_PERMISSIONS_RECORD_AUDIO))
                        .show();
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.RECORD_AUDIO},
                        MY_PERMISSIONS_RECORD_AUDIO);
            }
            return;
        }

        // مجوز قبلاً داده شده
        handleStartRequest(typeStart);
    }

    private void handleStartRequest(int typeStart) {
        if (typeStart == 1) startGame();
        else dialogCreateShow(startGameView);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == MY_PERMISSIONS_RECORD_AUDIO) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                if (saveButtonPressing == 1) startGame();
                else dialogCreateShow(startGameView);
            } else {
                Toast.makeText(this, "اجرای بازی بدون اجازه میکروفون امکان\u200Cپذیر نیست.", Toast.LENGTH_LONG).show();
            }
        }
    }

    // ----- شروع بازی -----
    private void startGame() {
        if (PublicInfo.checkStartClient > 0) {
            if (PublicInfo.checkStartClient == 2 && Build.VERSION.SDK_INT <= Build.VERSION_CODES.M) {
                Toast toast = Toast.makeText(getApplicationContext(),
                        "Бета доступна только на Android 6 и выше.",
                        Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                return;
            }
            startActivity(new Intent(MenuActivity.this, MainStart.class));
            overridePendingTransition(0, 0);
        } else {
            dialogCreateShow(startGameView);
        }
    }

    // ----- باز کردن دیالوگ / تنظیمات ذخیره شده -----
    private void OpenDialogIfNeeded() {
        if (mSettings.contains(APP_PREFERENCES_DIALOG)) {
            PublicInfo.checkStartClient = mSettings.getInt(APP_PREFERENCES_DIALOG, 0);
        }
    }

    private void dialogCreateShow(View v) {
        // در نسخه اصلی این متد یک Intent ساده اجرا می‌کرد؛ نگه داشته شد
        startActivity(new Intent(MenuActivity.this, MainStart.class));
        overridePendingTransition(0, 0);
    }

    // ----- وضعیت سرور ثابت Dexin Mobile -----
    private void updateFixedServerCard() {
        textViewServerCount.setText("Dexin Mobile");
        progressBarServer.setProgress(100);
    }

    // ----- ذخیره تنظیمات بازی (مثال) -----
    public static void SaveOptims(int storage, String dirgame) throws IOException {
        Wini inid = new Wini(new File(Environment.getExternalStorageDirectory() + "/DexinMobile/files.ini"));
        inid.put("storage", "type", storage);
        inid.put("storage", "dirgame", dirgame);
        inid.store();

        PublicInfo.dirGameLocalType = storage;
        System.out.println("MIHAIL typeGameStorage save def");
    }

    // ----- کار با نیک‌نیم -----
    private void openNick() throws IOException {
        Wini ini = new Wini(new File(PublicInfo.dirGameLocal + "/SAMP/settings.ini"));
        nickName = ini.get("client", "name");
    }

    private void saveNick() throws IOException {
        Wini ini = new Wini(new File(Environment.getExternalStorageDirectory() + "/DexinMobile/SAMP/settings.ini"));
        nickName = editTextName.getText().toString();
        ini.put("client", "name", nickName.replaceAll(" ", ""));
        ini.store();

        ReadNick.writeNickMods(CheckLoadingFiles.getModsID());

        new MainDialogFragment(
                "ذخیره نام کاربری",
                "نام کاربری شما " + nickName + " با موفقیت ذخیره شد!",
                "بستن",
                null,
                () -> recreate(),
                null
        ).show(getSupportFragmentManager(), "saveNick");
    }
    
    // ----- متد کمکی: لیست بازگشتی فایل‌ها با کنترل null -----
    public static List<File> listFilesRecursive(String directoryName) {
        List<File> result = new ArrayList<>();
        File directory = new File(directoryName);
        if (!directory.exists() || !directory.isDirectory()) return result;

        File[] files = directory.listFiles();
        if (files == null) return result;

        for (File f : files) {
            result.add(f);
            if (f.isDirectory()) {
                result.addAll(listFilesRecursive(f.getAbsolutePath()));
            }
        }
        return result;
    }
}
