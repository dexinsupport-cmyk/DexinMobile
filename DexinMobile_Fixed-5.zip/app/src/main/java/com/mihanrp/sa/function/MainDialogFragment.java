package com.mihanrp.sa.function;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.mihanrp.core.R;

public class MainDialogFragment extends DialogFragment {

    private final String titleText;
    private final String descriptionText;
    private final String positiveText;
    private final String negativeText;
    private final Runnable onPositiveClick;
    private final Runnable onNegativeClick;

    public MainDialogFragment(
            String title,
            String description,
            String positive,
            String negative,
            Runnable onPositive,
            Runnable onNegative
    ) {
        this.titleText = title;
        this.descriptionText = description;
        this.positiveText = positive;
        this.negativeText = negative;
        this.onPositiveClick = onPositive;
        this.onNegativeClick = onNegative;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        // ایجاد دیالوگ
        Dialog dialog = new Dialog(requireContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        // Inflate layout
        View dialogView = LayoutInflater.from(getContext())
                .inflate(R.layout.dialog, null);
        dialog.setContentView(dialogView);

        // یافتن المان‌ها
        TextView title = dialogView.findViewById(R.id.tv_heading);
        TextView description = dialogView.findViewById(R.id.tv_description);
        TextView btnPositive = dialogView.findViewById(R.id.btn_positive);
        TextView btnNegative = dialogView.findViewById(R.id.btn_negative);
        View barrier = dialogView.findViewById(R.id.barrier);

        // تنظیم متن‌ها
        title.setText(titleText);
        description.setText(descriptionText);
        btnPositive.setText(positiveText);

        if (negativeText != null) {
            btnNegative.setText(negativeText);
            btnNegative.setVisibility(View.VISIBLE);
            barrier.setVisibility(View.VISIBLE); // فقط وقتی دو دکمه داریم
        } else {
            btnNegative.setVisibility(View.GONE);
            barrier.setVisibility(View.GONE); // وقتی تک دکمه است، مخفی شود
        }

        // اکشن دکمه‌ها
        btnPositive.setOnClickListener(v -> {
            if (onPositiveClick != null) onPositiveClick.run();
            dismiss();
        });

        btnNegative.setOnClickListener(v -> {
            if (onNegativeClick != null) onNegativeClick.run();
            dismiss();
        });

        // سفارشی‌سازی Window
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.setCancelable(false);

            // تنظیم عرض با margin واقعی
            int marginDp = 40; // فاصله از کناره‌ها
            int width = getScreenWidth() - dpToPx(marginDp) * 2;
            dialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        }

        return dialog;
    }

    // Helper: تبدیل dp به px
    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    // Helper: گرفتن عرض صفحه
    private int getScreenWidth() {
        DisplayMetrics metrics = new DisplayMetrics();
        requireActivity().getWindowManager().getDefaultDisplay().getMetrics(metrics);
        return metrics.widthPixels;
    }
}
