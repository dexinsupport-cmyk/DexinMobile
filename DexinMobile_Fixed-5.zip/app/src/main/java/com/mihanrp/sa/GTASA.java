package com.mihanrp.sa;
import android.content.Intent;
import android.os.Bundle;

import com.mihanrp.sa.function.BaseActivity;

public class GTASA extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        Intent intent=new Intent(this, LoadingApp.class);
        intent.putExtras(getIntent());
        startActivity(intent);
        finish();
    }
}