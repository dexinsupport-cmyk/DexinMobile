package com.mihanrp.sa;

import android.content.Intent;
import android.os.Environment;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;

import com.mihanrp.sa.function.BaseActivity;
import com.mihanrp.sa.jsonenter.PublicInfo;
import com.mihanrp.core.R;

import org.ini4j.Wini;

import java.io.File;
import java.io.IOException;

import androidx.appcompat.app.AppCompatActivity;

public class IntallNickActivity extends BaseActivity {

    String nickName;
    EditText editTextName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intall_nick);

        try {
            OpenNick();
        } catch (IOException e) {
            e.printStackTrace();
        }

        editTextName = (EditText) findViewById(R.id.editTextChangeName);
        if(nickName != null || nickName != "Nick_Name") editTextName.setText(nickName);


        ImageView buttonSaveNick = (ImageView) findViewById(R.id.buttonSaveNick);
        buttonSaveNick.setClickable(true);
        buttonSaveNick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    SaveNick();
                } catch (IOException e) {
                    e.printStackTrace();
                    Intent intent = new Intent(IntallNickActivity.this, MenuActivity.class);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                }

            }
        });;

    }


    public void OpenNick() throws IOException {
        Wini ini = new Wini(new File(Environment.getExternalStorageDirectory()+"/DexinMobile/SAMP/settings.ini"));
        nickName = ini.get("client", "name");

        //Log.d(TAG, "Ваш ник: "+nickName);
    }

    public void SaveNick() throws IOException {
        Wini ini = new Wini(new File(Environment.getExternalStorageDirectory()+"/DexinMobile/SAMP/settings.ini"));
        nickName = editTextName.getText().toString();
        ini.put("client", "name", nickName);
        ini.store();


        System.out.println("МИХАИЛ Приложение установилось!");
        PublicInfo.successInstallApk = true;
        try {
            SaveSetings();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Intent intent = new Intent(IntallNickActivity.this, MenuActivity.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
    }

    public void SaveSetings() throws IOException {
        Wini ini = new Wini(new File(getExternalFilesDir(null)+"/settings.ini"));
        ini.put("app", "loading_start", 0);
        ini.put("app", "install", 4);
        ini.store();
    }

}
