package com.mihanrp.sa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mihanrp.sa.jsonenter.PublicInfo;
import com.mihanrp.core.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import com.mihanrp.sa.function.BaseActivity;

public class ContactActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        ImageView imageViewIconDiscord = findViewById(R.id.imageViewIconDiscord);
        imageViewIconDiscord.setClickable(true);
        imageViewIconDiscord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isOnline(ContactActivity.this)) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "شما به اینترنت متصل نیستید!",
                            Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                } else {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(PublicInfo.contactDiscord));
                    startActivity(browserIntent);
                    overridePendingTransition(0, 0);
                }
            }
        });

        ImageView imageViewIconInstagram = findViewById(R.id.imageViewIconInstagram);
        imageViewIconInstagram.setClickable(true);
        imageViewIconInstagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isOnline(ContactActivity.this)) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "شما به اینترنت متصل نیستید!",
                            Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                } else {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(PublicInfo.contactInstagram));
                    startActivity(browserIntent);
                    overridePendingTransition(0, 0);
                }
            }
        });

        ImageView imageViewIconTelegram = findViewById(R.id.imageViewIconTelegram);
        imageViewIconTelegram.setClickable(true);
        imageViewIconTelegram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isOnline(ContactActivity.this)) {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "شما به اینترنت متصل نیستید!",
                            Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                } else {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(PublicInfo.contactTelegram));
                    startActivity(browserIntent);
                    overridePendingTransition(0, 0);
                }
            }
        });

        TextView imageDownLeftMenu = findViewById(R.id.imageDownLeftMenu);
        imageDownLeftMenu.setClickable(true);
        imageDownLeftMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ContactActivity.this, SetingsActivity.class);
                startActivity(intent);
                overridePendingTransition(0, 0);
            }
        });

        FloatingActionButton imageDownCenterMenu = findViewById(R.id.imageDownCenterMenu);
        imageDownCenterMenu.setClickable(true);

        imageDownCenterMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ContactActivity.this, MenuActivity.class);
                intent.putExtra("startGame", true);
                intent.putExtra("typeStart", 1);
                startActivity(intent);
                overridePendingTransition(0, 0);
            }

        });

        imageDownCenterMenu.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                Intent intent = new Intent(ContactActivity.this, MenuActivity.class);
                intent.putExtra("startGame", true);
                intent.putExtra("typeStart", 2);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return false;
            }
        });

        TextView imageDownRightMenu = findViewById(R.id.imageDownRightMenu);
        imageDownRightMenu.setClickable(true);
        imageDownRightMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ContactActivity.this, MenuActivity.class);
                startActivity(intent);
                overridePendingTransition(0, 0);
            }
        });
    }

    public static boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }
}
