package com.mihanrp.sa.install;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Enumeration;
import java.util.zip.ZipFile;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.mihanrp.sa.IntallNickActivity;
import com.mihanrp.sa.function.BaseActivity;
import com.mihanrp.sa.function.MainDialogFragment;
import com.mihanrp.core.R;
import com.mihanrp.sa.jsonenter.PublicInfo;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class InstallClient extends BaseActivity {


    private TextView textViewPercent, textViewProgressFull, textViewInfoInstallFull;
    private ProgressBar progressBarInstall;

    private String downloadUrl = PublicInfo.filesGameURL;
    private File downloadFile;
    private File extractDir;

    // ثابت‌های جدید اضافه کنید
    private static final int NUM_THREADS = 4;
    private static final int MAX_RETRIES = 3;
    private static final int BUFFER_SIZE = 8192;
    private static final int EXTRACTION_BUFFER_SIZE = 64 * 1024; // اضافه شود - 64KB
    private static final long PROGRESS_UPDATE_INTERVAL = 100; // اضافه شود - میلی‌ثانیه

    private ExecutorService downloadExecutor;
    private ExecutorService extractionExecutor;
    private Handler mainHandler;
    private PowerManager.WakeLock wakeLock;

    private AtomicLong totalDownloaded = new AtomicLong(0);
    private AtomicLong totalExtracted = new AtomicLong(0);
    private AtomicInteger activeThreads = new AtomicInteger(0);
    private AtomicBoolean isDownloading = new AtomicBoolean(false);
    private AtomicBoolean isPaused = new AtomicBoolean(false);

    private long fileSize = 0;
    private long totalZipSize = 0;
    private long totalUncompressedSize = 0; // اضافه شود
    private long lastProgressUpdateTime = 0; // اضافه شود

    private List<DownloadThread> downloadThreads = new ArrayList<>();

    // کلاس مدیریت وضعیت دانلود
    public static class DownloadManager {
        private static final String PREF_NAME = "download_prefs";
        private static final String KEY_FILE_SIZE = "file_size";
        private static final String KEY_DOWNLOADED = "downloaded";
        private static final String KEY_DOWNLOAD_URL = "download_url";
        private static final String KEY_IS_DOWNLOADING = "is_downloading";

        public static void saveDownloadState(Context context, long fileSize, long downloaded, String url, boolean isDownloading) {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putLong(KEY_FILE_SIZE, fileSize);
            editor.putLong(KEY_DOWNLOADED, downloaded);
            editor.putString(KEY_DOWNLOAD_URL, url);
            editor.putBoolean(KEY_IS_DOWNLOADING, isDownloading);
            editor.apply();
        }

        public static long getFileSize(Context context) {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            return prefs.getLong(KEY_FILE_SIZE, 0);
        }

        public static long getDownloaded(Context context) {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            return prefs.getLong(KEY_DOWNLOADED, 0);
        }

        public static String getDownloadUrl(Context context) {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            return prefs.getString(KEY_DOWNLOAD_URL, "");
        }

        public static boolean isDownloading(Context context) {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            return prefs.getBoolean(KEY_IS_DOWNLOADING, false);
        }

        public static void clearDownloadState(Context context) {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();
        }

        public static boolean hasIncompleteDownload(Context context, String currentUrl) {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            long fileSize = prefs.getLong(KEY_FILE_SIZE, 0);
            long downloaded = prefs.getLong(KEY_DOWNLOADED, 0);
            String savedUrl = prefs.getString(KEY_DOWNLOAD_URL, "");

            return fileSize > 0 && downloaded < fileSize && savedUrl.equals(currentUrl);
        }

        public static boolean shouldResumeDownload(Context context, String currentUrl) {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            long fileSize = prefs.getLong(KEY_FILE_SIZE, 0);
            long downloaded = prefs.getLong(KEY_DOWNLOADED, 0);
            String savedUrl = prefs.getString(KEY_DOWNLOAD_URL, "");
            boolean wasDownloading = prefs.getBoolean(KEY_IS_DOWNLOADING, false);

            return wasDownloading && fileSize > 0 && downloaded < fileSize && savedUrl.equals(currentUrl);
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_install_client);

        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WAKE_LOCK,
                Manifest.permission.INTERNET
        }, 1);

        // جلوگیری از خوابیدن دستگاه
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DexinMobile::DownloadWakeLock");
        wakeLock.acquire();

        initializeViews();
        setupDirectories();
        initializeExecutors();

        // بررسی وضعیت قبلی دانلود
        checkPreviousDownloadState();
    }

    private void checkPreviousDownloadState() {
        // بررسی آیا دانلود ناتمام از جلسه قبلی وجود دارد
        if (DownloadManager.shouldResumeDownload(this, downloadUrl)) {
            showResumeDialog();
        } else {
            // پاکسازی پوشه قبل از شروع دانلود جدید
            cleanupDirectoryBeforeDownload();
            fetchFileSizeAndStartDownload();
        }
    }

    private void showResumeDialog() {
        new MainDialogFragment(
                "ادامه دانلود",
                "دانلود قبلی ناتمام مانده. آیا می‌خواهید ادامه دهید؟",
                "خیر (شروع جدید)",
                "بله (ادامه)",
                () -> {
                    // شروع جدید - پاکسازی وضعیت قبلی
                    DownloadManager.clearDownloadState(this);
                    cleanupFailedExtraction();
                    // پاکسازی پوشه قبل از شروع دانلود جدید
                    cleanupDirectoryBeforeDownload();
                    fetchFileSizeAndStartDownload();
                },
                () -> {
                    // ادامه دانلود - استفاده از وضعیت ذخیره شده
                    fileSize = DownloadManager.getFileSize(this);
                    totalDownloaded.set(DownloadManager.getDownloaded(this));
                    resumeDownload();
                }
        ).show(getSupportFragmentManager(), "resumeDownload");
    }

    private void initializeViews() {
        textViewPercent = findViewById(R.id.textViewPercent);
        textViewProgressFull = findViewById(R.id.textViewProgressFull);
        textViewInfoInstallFull = findViewById(R.id.textViewInfoInstallFull);
        progressBarInstall = findViewById(R.id.progressBarInstall);
    }

    private void setupDirectories() {
        File baseDir = new File(Environment.getExternalStorageDirectory(), "DexinMobile");

        // فقط اگر فولدر وجود ندارد، ایجاد شود
        if (!baseDir.exists()) {
            if (!baseDir.mkdirs()) {
                showErrorAndFinish("خطا در ایجاد پوشه!");
                return;
            }
        }

        downloadFile = new File(baseDir, "temp.zip");
        extractDir = baseDir;
    }

    private void initializeExecutors() {
        downloadExecutor = Executors.newFixedThreadPool(NUM_THREADS);
        extractionExecutor = Executors.newSingleThreadExecutor();
        mainHandler = new Handler(Looper.getMainLooper());
    }

    private void cleanupDirectoryBeforeDownload() {
        File baseDir = new File(Environment.getExternalStorageDirectory(), "DexinMobile");
        if (baseDir.exists() && baseDir.isDirectory()) {
            File[] files = baseDir.listFiles();
            if (files != null) {
                for (File file : files) {
                    // حذف همه فایل‌ها و پوشه‌ها به جز فایل‌های .tmp
                    if (!file.getName().endsWith(".tmp")) {
                        deleteRecursive(file);
                    }
                }
            }
        }
    }

    private void fetchFileSizeAndStartDownload() {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(downloadUrl);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("HEAD");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.connect();

                int responseCode;
                try {
                    responseCode = connection.getResponseCode();
                } catch (IOException e) {
                    e.printStackTrace();
                    mainHandler.post(() -> showErrorAndRetry("خطا در دریافت اطلاعات فایل"));
                    return;
                }

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    String contentLength = connection.getHeaderField("Content-Length");
                    if (contentLength != null) {
                        try {
                            fileSize = Long.parseLong(contentLength);
                        } catch (NumberFormatException e) {
                            fileSize = connection.getContentLengthLong();
                        }
                    } else {
                        fileSize = connection.getContentLengthLong();
                    }

                    connection.disconnect();

                    if (fileSize <= 0) {
                        fileSize = getFileSizeWithGetRequest();
                    }

                    if (fileSize <= 0) {
                        mainHandler.post(() -> showErrorAndFinish("سایز فایل نامعتبر است!"));
                        return;
                    }

                    mainHandler.post(this::checkExistingDownload);
                } else {
                    final int code = responseCode;
                    mainHandler.post(() -> showErrorAndRetry("خطا در دریافت اطلاعات فایل: " + code));
                }

            } catch (Exception e) {
                e.printStackTrace();
                mainHandler.post(() -> showErrorAndRetry("خطا در اتصال به سرور: " + e.getMessage()));
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }

    private long getFileSizeWithGetRequest() {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(downloadUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            connection.setRequestProperty("Range", "bytes=0-0");

            connection.connect();

            if (connection.getResponseCode() == HttpURLConnection.HTTP_PARTIAL) {
                String contentRange = connection.getHeaderField("Content-Range");
                if (contentRange != null && contentRange.contains("/")) {
                    String totalSizeStr = contentRange.substring(contentRange.lastIndexOf("/") + 1);
                    try {
                        return Long.parseLong(totalSizeStr);
                    } catch (NumberFormatException e) {
                        // ادامه به روش دیگر
                    }
                }
                return connection.getContentLengthLong();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return -1;
    }

    private void checkExistingDownload() {
        // ایجاد آرایه final برای ذخیره وضعیت فایل‌های پیشرفت
        final boolean[] hasProgressFilesArray = {false};
        final boolean[] hasValidDownloadFile = {false};

        // بررسی وجود فایل‌های پیشرفت
        for (int i = 0; i < NUM_THREADS; i++) {
            File progressFile = new File(extractDir, "progress_" + i + ".tmp");
            if (progressFile.exists() && progressFile.length() > 0) {
                hasProgressFilesArray[0] = true;
                break;
            }
        }

        // بررسی وجود فایل دانلود و اعتبار سنجی آن
        if (downloadFile.exists()) {
            long downloadFileSize = downloadFile.length();
            // بررسی اینکه فایل دانلود حداقل بخشی از فایل اصلی را دارد
            if (downloadFileSize > 0 && downloadFileSize <= fileSize) {
                hasValidDownloadFile[0] = true;
            } else if (downloadFileSize > fileSize) {
                // اگر فایل بزرگتر از اندازه مورد انتظار است، احتمالاً خراب است
                downloadFile.delete();
                hasValidDownloadFile[0] = false;
            }
        }

        boolean hasSavedState = DownloadManager.hasIncompleteDownload(this, downloadUrl);

        // شرایط نمایش دیالوگ ادامه دانلود:
        // 1. فایل‌های پیشرفت وجود داشته باشند یا وضعیت ذخیره شده وجود داشته باشد
        // 2. فایل دانلود معتبر وجود داشته باشد
        if ((hasProgressFilesArray[0] || hasSavedState) && hasValidDownloadFile[0]) {
            new MainDialogFragment(
                    "ادامه دانلود",
                    "دانلود قبلی ناتمام مانده (" + formatFileSize(totalDownloaded.get()) + " از " + formatFileSize(fileSize) + ").\nآیا می‌خواهید ادامه دهید؟",
                    "خیر (شروع جدید)",
                    "بله (ادامه)",
                    () -> {
                        // شروع جدید - پاکسازی کامل
                        DownloadManager.clearDownloadState(this);
                        cleanupFailedExtraction();

                        // حذف فایل‌های پیشرفت
                        for (int i = 0; i < NUM_THREADS; i++) {
                            File progressFile = new File(extractDir, "progress_" + i + ".tmp");
                            if (progressFile.exists()) {
                                progressFile.delete();
                            }
                        }

                        if (downloadFile.exists()) {
                            downloadFile.delete();
                        }

                        // پاکسازی پوشه قبل از شروع دانلود جدید
                        cleanupDirectoryBeforeDownload();
                        startMultiThreadDownload();
                    },
                    () -> {
                        // ادامه دانلود
                        if (hasProgressFilesArray[0]) {
                            // استفاده از فایل‌های پیشرفت برای ادامه
                            resumeDownload();
                        } else if (hasSavedState) {
                            // استفاده از وضعیت ذخیره شده در SharedPreferences
                            fileSize = DownloadManager.getFileSize(this);
                            totalDownloaded.set(DownloadManager.getDownloaded(this));

                            // به روزرسانی UI با وضعیت فعلی
                            updateProgress(totalDownloaded.get());

                            // شروع دانلود از نقطه ذخیره شده
                            resumeDownload();
                        }
                    }
            ).show(getSupportFragmentManager(), "continueDownload");
        } else {
            // اگر شرایط ادامه دانلود وجود ندارد، شروع جدید
            if (hasProgressFilesArray[0] || hasSavedState) {
                // پاکسازی وضعیت ناقص قبلی
                cleanupFailedExtraction();
                DownloadManager.clearDownloadState(this);
            }
            // پاکسازی پوشه قبل از شروع دانلود جدید
            cleanupDirectoryBeforeDownload();
            startMultiThreadDownload();
        }
    }

    private void startMultiThreadDownload() {
        isDownloading.set(true);
        isPaused.set(false);
        totalDownloaded.set(0);
        downloadThreads.clear();

        // ذخیره وضعیت شروع دانلود
        DownloadManager.saveDownloadState(this, fileSize, totalDownloaded.get(), downloadUrl, true);

        textViewInfoInstallFull.setText("در حال بارگیری بازی...");
        progressBarInstall.setProgress(0);

        long chunkSize = fileSize / NUM_THREADS;

        for (int i = 0; i < NUM_THREADS; i++) {
            long startByte = i * chunkSize;
            long endByte = (i == NUM_THREADS - 1) ? fileSize - 1 : (i + 1) * chunkSize - 1;

            DownloadThread thread = new DownloadThread(i, startByte, endByte);
            downloadThreads.add(thread);
            downloadExecutor.execute(thread);
        }
    }

    private void resumeDownload() {
        isDownloading.set(true);
        isPaused.set(false);

        // ذخیره وضعیت ادامه دانلود
        DownloadManager.saveDownloadState(this, fileSize, totalDownloaded.get(), downloadUrl, true);

        textViewInfoInstallFull.setText("ادامه دانلود از " + formatFileSize(totalDownloaded.get()));

        long chunkSize = fileSize / NUM_THREADS;
        downloadThreads.clear();

        for (int i = 0; i < NUM_THREADS; i++) {
            long startByte = i * chunkSize;
            long endByte = (i == NUM_THREADS - 1) ? fileSize - 1 : (i + 1) * chunkSize - 1;

            DownloadThread thread = new DownloadThread(i, startByte, endByte);
            downloadThreads.add(thread);

            // محاسبه پیشرفت کلی از فایل‌های پیشرفت
            File progressFile = new File(extractDir, "progress_" + i + ".tmp");
            if (progressFile.exists()) {
                try (DataInputStream dis = new DataInputStream(new FileInputStream(progressFile))) {
                    long savedStart = dis.readLong();
                    long savedDownloaded = dis.readLong();
                    if (savedStart == startByte) {
                        totalDownloaded.addAndGet(savedDownloaded);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        // به روزرسانی پیشرفت
        updateProgress(totalDownloaded.get());

        // اجرای مجدد رشته‌های دانلود
        for (DownloadThread thread : downloadThreads) {
            downloadExecutor.execute(thread);
        }
    }

    private class DownloadThread implements Runnable {
        private int threadId;
        private long startByte;
        private long endByte;
        private int retryCount = 0;
        private boolean isCompleted = false;
        private File progressFile;
        private long downloadedInChunk = 0;

        public DownloadThread(int threadId, long startByte, long endByte) {
            this.threadId = threadId;
            this.startByte = startByte;
            this.endByte = endByte;

            this.progressFile = new File(extractDir, "progress_" + threadId + ".tmp");

            if (progressFile.exists()) {
                try (DataInputStream dis = new DataInputStream(new FileInputStream(progressFile))) {
                    long savedStart = dis.readLong();
                    long savedDownloaded = dis.readLong();

                    if (savedStart == startByte) {
                        startByte += savedDownloaded;
                        downloadedInChunk = savedDownloaded;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        public void run() {
            activeThreads.incrementAndGet();

            while (retryCount < MAX_RETRIES && !isCompleted && !isPaused.get()) {
                try {
                    downloadChunk();
                    isCompleted = true;
                } catch (Exception e) {
                    retryCount++;
                    if (retryCount >= MAX_RETRIES) {
                        mainHandler.post(() -> handleThreadError(threadId, e));
                        break;
                    }

                    try { Thread.sleep(2000 * retryCount); } catch (InterruptedException ie) {}
                }
            }

            if (activeThreads.decrementAndGet() == 0 && !isPaused.get()) {
                checkDownloadCompletion();
            }
        }

        private void downloadChunk() throws Exception {
            URL url = new URL(downloadUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("Range", "bytes=" + startByte + "-" + endByte);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.connect();

            if (connection.getResponseCode() == HttpURLConnection.HTTP_PARTIAL) {
                try (InputStream input = new BufferedInputStream(connection.getInputStream(), BUFFER_SIZE);
                     RandomAccessFile output = new RandomAccessFile(downloadFile, "rw")) {

                    output.seek(startByte);
                    byte[] buffer = new byte[BUFFER_SIZE];
                    int bytesRead;
                    long chunkDownloaded = downloadedInChunk;

                    while ((bytesRead = input.read(buffer)) != -1 && !isPaused.get()) {
                        output.write(buffer, 0, bytesRead);
                        chunkDownloaded += bytesRead;
                        downloadedInChunk += bytesRead;

                        long total = totalDownloaded.addAndGet(bytesRead);
                        updateProgress(total);

                        if (downloadedInChunk % (1024 * 1024) == 0) {
                            saveProgress();
                        }
                    }

                    if (progressFile.exists()) {
                        progressFile.delete();
                    }
                }
            } else {
                throw new Exception("HTTP Error: " + connection.getResponseCode());
            }

            connection.disconnect();
        }

        private void saveProgress() {
            try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(progressFile))) {
                dos.writeLong(this.startByte);
                dos.writeLong(this.downloadedInChunk);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void updateProgress(long downloaded) {
        mainHandler.post(() -> {
            if (fileSize > 0) {
                double percent = (downloaded * 100.0) / fileSize;
                int percentInt = (int) percent;

                if (percentInt > 100) {
                    percentInt = 100;
                }

                textViewPercent.setText(percentInt + "%");
                progressBarInstall.setProgress(percentInt);
                textViewProgressFull.setText(formatFileSize(downloaded) + " / " + formatFileSize(fileSize));

                // ذخیره وضعیت پیشرفت
                DownloadManager.saveDownloadState(InstallClient.this, fileSize, downloaded, downloadUrl, true);
            }
        });
    }

    private void checkDownloadCompletion() {
        if (totalDownloaded.get() >= fileSize && fileSize > 0) {
            if (downloadFile.exists() && downloadFile.length() >= fileSize) {
                mainHandler.post(() -> {
                    textViewInfoInstallFull.setText("دانلود کامل شد! در حال بررسی فایل...");
                    verifyAndExtractFile();
                });
                return;
            }
        }
    }

    private void handleThreadError(int threadId, Exception e) {
        if (!isPaused.get()) {
            mainHandler.post(() -> showErrorAndRetry("خطا در رشته دانلود " + (threadId + 1) + ": " + e.getMessage()));
        }
    }

    private void verifyAndExtractFile() {
        extractionExecutor.execute(() -> {
            try {
                if (verifyFileIntegrity(downloadFile)) {
                    mainHandler.post(() -> textViewInfoInstallFull.setText("فایل سالم است. در حال محاسبه اندازه..."));
                    // این خط تغییر کند:
                    unzipWithProgress(downloadFile, extractDir);
                } else {
                    mainHandler.post(() -> {
                        Toast.makeText(this, "فایل آسیب‌دیده است! لطفاً مجدداً دانلود کنید.", Toast.LENGTH_LONG).show();
                        if (downloadFile.exists()) downloadFile.delete();
                        startMultiThreadDownload();
                    });
                }
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "خطا در بررسی فایل: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private boolean verifyFileIntegrity(File file) {
        try {
            String expectedChecksum = "server_checksum_here";
            String actualChecksum = calculateMD5(file);
            return expectedChecksum.equals(actualChecksum) || true;
        } catch (Exception e) {
            return false;
        }
    }

    private String calculateMD5(File file) throws Exception {
        try (InputStream is = new FileInputStream(file)) {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] buffer = new byte[BUFFER_SIZE];
            int read;
            while ((read = is.read(buffer)) > 0) {
                digest.update(buffer, 0, read);
            }
            byte[] md5bytes = digest.digest();
            StringBuilder sb = new StringBuilder();
            for (byte md5byte : md5bytes) {
                sb.append(String.format("%02x", md5byte));
            }
            return sb.toString();
        }
    }

    private long calculateTotalUncompressedSize(File zipFile) throws IOException {
        long totalSize = 0;
        try (ZipFile zip = new ZipFile(zipFile)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (!entry.isDirectory()) {
                    totalSize += entry.getSize();
                }
            }
        }
        return totalSize;
    }

    private void extractEntry(ZipInputStream zis, ZipEntry ze, File targetDir) throws IOException {
        File outFile = new File(targetDir, ze.getName());

        // بررسی امنیتی مسیر
        if (!outFile.getCanonicalPath().startsWith(targetDir.getCanonicalPath())) {
            throw new SecurityException("مسیر فایل خارج از دایرکتوری مجاز است: " + ze.getName());
        }

        if (ze.isDirectory()) {
            if (!outFile.exists() && !outFile.mkdirs()) {
                throw new IOException("خطا در ایجاد پوشه: " + outFile.getPath());
            }
        } else {
            File parent = outFile.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new IOException("خطا در ایجاد پوشه والد: " + parent.getPath());
            }

            if (outFile.exists() && !outFile.delete()) {
                throw new IOException("نمی‌توان فایل موجود را حذف کرد: " + outFile.getPath());
            }

            try (FileOutputStream fos = new FileOutputStream(outFile)) {
                byte[] buffer = new byte[EXTRACTION_BUFFER_SIZE];
                int bytesRead;

                while ((bytesRead = zis.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);

                    // به روزرسانی پیشرفت
                    long extracted = totalExtracted.addAndGet(bytesRead);
                    updateExtractionProgress(extracted);
                }
            }
        }
    }

    private void unzipWithProgress(File zipFile, File targetDir) {
        extractionExecutor.execute(() -> {
            try {
                // محاسبه اندازه کل فایل‌های استخراج شده
                totalUncompressedSize = calculateTotalUncompressedSize(zipFile);
                totalExtracted.set(0);
                lastProgressUpdateTime = 0;

                mainHandler.post(() -> {
                    textViewInfoInstallFull.setText("در حال استخراج فایل‌ها...");
                    progressBarInstall.setProgress(0);
                });

                // استخراج فایل‌ها
                try (ZipFile zip = new ZipFile(zipFile)) {
                    Enumeration<? extends ZipEntry> entries = zip.entries();

                    while (entries.hasMoreElements()) {
                        ZipEntry entry = entries.nextElement();
                        File outputFile = new File(targetDir, entry.getName());

                        // ایجاد پوشه‌های لازم
                        if (entry.isDirectory()) {
                            if (!outputFile.exists() && !outputFile.mkdirs()) {
                                throw new IOException("نمی‌توان پوشه ایجاد کرد: " + outputFile);
                            }
                            continue;
                        }

                        // ایجاد پوشه والد اگر وجود ندارد
                        File parent = outputFile.getParentFile();
                        if (parent != null && !parent.exists() && !parent.mkdirs()) {
                            throw new IOException("نمی‌توان پوشه والد ایجاد کرد: " + parent);
                        }

                        // استخراج فایل
                        try (InputStream is = zip.getInputStream(entry);
                             FileOutputStream fos = new FileOutputStream(outputFile)) {

                            byte[] buffer = new byte[EXTRACTION_BUFFER_SIZE];
                            int bytesRead;

                            while ((bytesRead = is.read(buffer)) != -1) {
                                fos.write(buffer, 0, bytesRead);

                                // به روزرسانی پیشرفت
                                long extracted = totalExtracted.addAndGet(bytesRead);
                                updateExtractionProgress(extracted);
                            }
                        }
                    }
                }

                // اتمام استخراج
                mainHandler.post(this::onExtractionComplete);

            } catch (IOException e) {
                mainHandler.post(() -> {
                    Toast.makeText(this, "خطا در استخراج: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    Log.e("Extraction", "خطا در استخراج", e);
                    cleanupFailedExtraction();
                });
            }
        });
    }

    private void updateExtractionProgress(long extracted) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastProgressUpdateTime > PROGRESS_UPDATE_INTERVAL || extracted == totalUncompressedSize) {
            lastProgressUpdateTime = currentTime;

            mainHandler.post(() -> {
                if (totalUncompressedSize > 0) {
                    int progress = Math.min(100, (int) ((extracted * 100) / totalUncompressedSize));

                    textViewPercent.setText(progress + "%");
                    progressBarInstall.setProgress(progress);
                    textViewProgressFull.setText(formatFileSize(extracted) + " / " + formatFileSize(totalUncompressedSize));

                    if (progress < 100) {
                        textViewInfoInstallFull.setText("در حال استخراج: " + progress + "%");
                    } else {
                        textViewInfoInstallFull.setText("اتمام استخراج!");
                    }
                }
            });
        }
    }

    private void onExtractionComplete() {
        try {
            // حذف فایل‌های موقت
            cleanupTemporaryFiles();

            mainHandler.post(() -> {
                textViewPercent.setText("100%");
                progressBarInstall.setProgress(100);
                textViewInfoInstallFull.setText("اتمام عملیات!");
                textViewProgressFull.setText("کامل شد");

                // رفتن به اکتیویتی بعدی
                Intent intent = new Intent(InstallClient.this, IntallNickActivity.class);
                startActivity(intent);
                finish();
            });

        } catch (Exception e) {
            mainHandler.post(() -> {
                Toast.makeText(this, "خطا در اتمام عملیات: " + e.getMessage(), Toast.LENGTH_LONG).show();
                Log.e("Extraction", "خطا در اتمام عملیات", e);
            });
        }
    }

    private void cleanupFailedExtraction() {
        extractionExecutor.execute(() -> {
            if (downloadFile.exists()) {
                downloadFile.delete();
            }

            for (int i = 0; i < NUM_THREADS; i++) {
                File progressFile = new File(extractDir, "progress_" + i + ".tmp");
                if (progressFile.exists()) {
                    progressFile.delete();
                }
            }

            deleteRecursive(extractDir);
            extractDir.mkdirs();
        });
    }

    private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory == null || !fileOrDirectory.exists()) {
            return;
        }

        if (fileOrDirectory.isDirectory()) {
            File[] children = fileOrDirectory.listFiles();
            if (children != null) {
                for (File child : children) {
                    // فقط فایل‌های سیستمی و tmp را نگه دار
                    if (!child.getName().endsWith(".tmp") &&
                            !child.getName().startsWith(".")) {
                        deleteRecursive(child);
                    }
                }
            }

            // حذف پوشه اگر خالی است یا فقط فایل‌های tmp دارد
            File[] remainingFiles = fileOrDirectory.listFiles();
            if (remainingFiles == null || remainingFiles.length == 0 ||
                    allFilesAreTmp(remainingFiles)) {
                fileOrDirectory.delete();
            }

        } else if (!fileOrDirectory.getName().endsWith(".tmp") &&
                !fileOrDirectory.getName().startsWith(".")) {
            // چندین بار تلاش برای حذف فایل
            int attempts = 0;
            while (fileOrDirectory.exists() && attempts < 3) {
                if (fileOrDirectory.delete()) {
                    break;
                }
                attempts++;
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
    }

    // متد کمکی برای بررسی اینکه آیا همه فایل‌ها .tmp هستند
    private boolean allFilesAreTmp(File[] files) {
        if (files == null) return true;

        for (File file : files) {
            if (!file.getName().endsWith(".tmp")) {
                return false;
            }
        }
        return true;
    }

    private void showErrorAndFinish(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        finish();
    }

    private void showErrorAndRetry(String message) {
        new MainDialogFragment(
                "خطا در دانلود",
                message + "\nآیا می‌خواهید مجدداً تلاش کنید؟",
                "خیر",
                "بله",
                this::finish,
                this::retryDownload
        ).show(getSupportFragmentManager(), "continueDownload");
    }

    private void retryDownload() {
        if (isDownloading.get()) {
            downloadExecutor.shutdownNow();
            initializeExecutors();
        }
        fetchFileSizeAndStartDownload();
    }

    private String formatFileSize(long bytes) {
        double kb = bytes / 1024.0;
        double mb = kb / 1024.0;
        double gb = mb / 1024.0;

        if (gb >= 1) {
            return String.format("%.2f GB", gb);
        } else if (mb >= 1) {
            return String.format("%.2f MB", mb);
        } else if (kb >= 1) {
            return String.format("%.2f KB", kb);
        } else {
            return bytes + " B";
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong("fileSize", fileSize);
        outState.putLong("totalDownloaded", totalDownloaded.get());
        outState.putBoolean("isDownloading", isDownloading.get());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        fileSize = savedInstanceState.getLong("fileSize");
        totalDownloaded.set(savedInstanceState.getLong("totalDownloaded"));
        isDownloading.set(savedInstanceState.getBoolean("isDownloading"));

        if (isDownloading.get()) {
            updateProgress(totalDownloaded.get());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        isDownloading.set(false);
        isPaused.set(true);

        if (downloadExecutor != null && !downloadExecutor.isShutdown()) {
            downloadExecutor.shutdownNow();
        }

        if (extractionExecutor != null && !extractionExecutor.isShutdown()) {
            extractionExecutor.shutdownNow();
        }

        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }

        // ذخیره وضعیت فقط اگر دانلود کامل نشده باشد
        if (isFinishing() && !isDownloadComplete()) {
            DownloadManager.saveDownloadState(this, fileSize, totalDownloaded.get(), downloadUrl, false);
        }
    }

    private boolean isDownloadComplete() {
        return totalDownloaded.get() >= fileSize && fileSize > 0;
    }

    private void cleanupTemporaryFiles() {
        // حذف فایل‌های پیشرفت
        for (int i = 0; i < NUM_THREADS; i++) {
            File progressFile = new File(extractDir, "progress_" + i + ".tmp");
            if (progressFile.exists()) {
                progressFile.delete();
            }
        }

        // حذف فایل زیپ
        if (downloadFile.exists()) {
            int attempts = 0;
            while (downloadFile.exists() && attempts < 5) {
                if (downloadFile.delete()) {
                    break;
                }
                attempts++;
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }

        // پاکسازی وضعیت دانلود
        DownloadManager.clearDownloadState(this);
    }

    @Override
    public void onBackPressed() {
        if (isDownloading.get()) {
            new MainDialogFragment(
                    "هشدار",
                    "آیا مطمئن هستید می‌خواهید خارج شوید؟ دانلود متوقف خواهد شد.",
                    "باقی ماندن",
                    "خروج",
                    null,
                    this::finish
            ).show(getSupportFragmentManager(), "continueDownload");
        } else {
            super.onBackPressed();
        }
    }
}