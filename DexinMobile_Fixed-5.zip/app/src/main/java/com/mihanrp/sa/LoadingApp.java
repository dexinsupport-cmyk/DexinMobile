package com.mihanrp.sa;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.StatFs;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.os.Bundle;
import com.mihanrp.sa.function.CheckLoadingFiles;
import com.mihanrp.sa.function.MainDialogFragment;
import com.mihanrp.sa.internet.ConnectionServer;
import com.mihanrp.sa.internet.LinkConnect;
import com.mihanrp.sa.jsonenter.DownloadData;
import com.mihanrp.sa.jsonenter.GetDeviceInfo;
import com.mihanrp.sa.jsonenter.PublicInfo;
import com.mihanrp.sa.model.NewsModel;
import com.mihanrp.core.R;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import cz.msebera.android.httpclient.Header;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.widget.ProgressBar;
import com.mihanrp.sa.function.BaseActivity;

public class LoadingApp extends BaseActivity {
    Context context;

    @SuppressLint("NewApi")
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading_app);

        MenuActivity.itemsNews = new ArrayList<NewsModel>();
        context = getApplicationContext();

        GetDeviceInfo getDeviceInfo = new GetDeviceInfo();

        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                requestData();
            } else {
                ActivityCompat.requestPermissions(LoadingApp.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }
        } else {
            requestData();
        }

        ProgressBar progressBar = findViewById(R.id.progressBar);
        ScaleAnimation scaleAnimation = new ScaleAnimation(
                1.0f, 1.2f,
                1.0f, 1.2f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f
        );
        scaleAnimation.setDuration(600);
        scaleAnimation.setRepeatMode(ScaleAnimation.REVERSE);
        scaleAnimation.setRepeatCount(ScaleAnimation.INFINITE);

        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.5f);
        alphaAnimation.setDuration(600);
        alphaAnimation.setRepeatMode(AlphaAnimation.REVERSE);
        alphaAnimation.setRepeatCount(AlphaAnimation.INFINITE);

        AnimationSet animationSet = new AnimationSet(true);
        animationSet.addAnimation(scaleAnimation);
        animationSet.addAnimation(alphaAnimation);
        progressBar.startAnimation(animationSet);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            requestData();
        } else {
            ActivityCompat.requestPermissions(LoadingApp.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    public boolean requestForPermission() {
        boolean isPermissionOn = true;
        final int version = Build.VERSION.SDK_INT;
        if (version >= 23) {
            if (!canAccessExternalSd()) {
                isPermissionOn = false;
                ActivityCompat.requestPermissions(this, EXTERNAL_PERMS, EXTERNAL_REQUEST);
            } else {
                requestData();
            }
        }
        return isPermissionOn;
    }

    private void requestData() {
        // Dexin Mobile uses one fixed server and does not depend on the old test/config API.
        PublicInfo.filesGameURL = PublicInfo.GAME_DOWNLOAD_URL;
        PublicInfo.urlMonitoring = null;
        PublicInfo.checkReleasePackageName = "com.mihanrp.sa";
        PublicInfo.checkStartClient = 1;

        try {
            if (CheckLoadingFiles.game()) {
                Intent intent = new Intent(LoadingApp.this, MenuActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(LoadingApp.this, LoadingGPU.class);
                startActivity(intent);
            }
            finish();
        } catch (IOException e) {
            e.printStackTrace();
            new MainDialogFragment(
                    "خطا در آماده سازی",
                    "فایل های بازی هنوز نصب نشده اند. ابتدا دانلود را انجام دهید.",
                    "باشه",
                    null,
                    null,
                    null
            ).show(getSupportFragmentManager(), "prepareError");
        }
    }

    public static int GetFreeMemory(String fileName) {
        File f = new File(fileName);
        StatFs stat = new StatFs(f.getPath());
        long bytesAvailable = stat.getBlockSizeLong() * stat.getAvailableBlocksLong();
        int total = (int) (bytesAvailable / (1024.f * 1024.f));
        return total;
    }

    public final String[] EXTERNAL_PERMS = {Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
    public final int EXTERNAL_REQUEST = 138;

    public boolean canAccessExternalSd() {
        return (hasPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE));
    }

    private boolean hasPermission(String perm) {
        return (PackageManager.PERMISSION_GRANTED == ContextCompat.checkSelfPermission(this, perm));
    }

    public static long folderSize(File directory) {
        if (directory == null) {
            return 0;
        }
        long length = 0;
        for (File file : directory.listFiles()) {
            if (file.isFile())
                length += file.length();
            else
                length += folderSize(file);
        }
        return length;
    }

    public static long getFolderSize(File file) {
        long size = 0;
        if (file.isDirectory()) {
            for (File child : file.listFiles()) {
                size += getFolderSize(child);
            }
        } else {
            size = file.length();
        }
        return size;
    }

    public Boolean installClient(String packageName) {
        android.content.Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
        return launchIntent != null;
    }

    public static String SHA1(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        byte[] textBytes = text.getBytes("iso-8859-1");
        md.update(textBytes, 0, textBytes.length);
        byte[] sha1hash = md.digest();
        return convertToHex(sha1hash);
    }

    private static String convertToHex(byte[] data) {
        StringBuilder buf = new StringBuilder();
        for (byte b : data) {
            int halfbyte = (b >>> 4) & 0x0F;
            int two_halfs = 0;
            do {
                buf.append((0 <= halfbyte) && (halfbyte <= 9) ? (char) ('0' + halfbyte) : (char) ('a' + (halfbyte - 10)));
                halfbyte = b & 0x0F;
            } while (two_halfs++ < 1);
        }
        return buf.toString();
    }
}