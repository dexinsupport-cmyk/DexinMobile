package com.mihanrp.sa.jsonenter;

public class SuccessSendData {

    public int insert;


    public SuccessSendData(){

    }
}