package com.mihanrp.sa;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ImageView;

import com.mihanrp.sa.function.BaseActivity;
import com.mihanrp.sa.install.InstallClient;
import com.mihanrp.sa.jsonenter.PublicInfo;
import com.mihanrp.core.R;

import static com.mihanrp.sa.LoadingApp.GetFreeMemory;

import java.io.File;

public class SelectInstallClient extends BaseActivity {

    boolean bOnce = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_install);

        ImageView buttonCClient = (ImageView) findViewById(R.id.InstallButton);
        buttonCClient.setClickable(true);
        buttonCClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!bOnce) {
                    bOnce = true;
                    String GetLogPath = Environment.getExternalStorageDirectory()  + "/MihanRP/";
                    String GetFileLogPath = Environment.getExternalStorageDirectory()  + "/MihanRP/logcat.txt";
                    try {
                        if (!new File(GetLogPath).exists()) {
                            new File(GetLogPath).mkdirs();
                        }
                        File file = new File(GetFileLogPath);
                        if (file.exists()) {
                            file.delete();
                        }
                        file.createNewFile();
                        Runtime runtime = Runtime.getRuntime();
                        runtime.exec("logcat -f " + file.getAbsolutePath());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if(GetFreeMemory(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/") > 1800) {
                    Intent intent = new Intent(SelectInstallClient.this, InstallClient.class);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                }
                else {
                    int freeMemory = GetFreeMemory(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/");
                    int needMemory = 3200-freeMemory;
                    AlertDialog.Builder builderSelectHelp;
                    builderSelectHelp = new AlertDialog.Builder(SelectInstallClient.this);
                    builderSelectHelp.setTitle("فضای کافی موجود نیست!");
                    builderSelectHelp.setMessage("برای نصب بازی به 3200MB نیاز است، پس از نصب بازی 2600MB فضا اشغال خواهد کرد، روی دستگاه شما "+freeMemory+" MB فضای آزاد موجود است، لطفاً "+needMemory+" MB فضا آزاد کنید");
                    builderSelectHelp.setNegativeButton("بستن", null);
                    AlertDialog alert = builderSelectHelp.create();
                    alert.show();
                }
            }
        });
    }
}
