package com.mihanrp.sa;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ConfigurationInfo;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mihanrp.sa.jsonenter.PublicInfo;
import com.mihanrp.core.R;

import java.util.HashMap;
import java.util.Map;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import com.mihanrp.sa.function.BaseActivity;

public class LoadingGPU extends BaseActivity implements GLSurfaceView.Renderer {

    private TextView textView;
    private GLSurfaceView glSurfaceView;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading_app);

        textView = findViewById(R.id.textLoadingApp);
        textView.setText("تعیین پردازنده گرافیکی شما...");

        final ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        final ConfigurationInfo configurationInfo = activityManager.getDeviceConfigurationInfo();

        this.glSurfaceView = new GLSurfaceView(this);
        this.glSurfaceView.setRenderer(this);
        ((ViewGroup) textView.getParent()).addView(this.glSurfaceView);

        intent = new Intent(this, SelectInstallClient.class);

        new CountDownTimer(3000, 9999) {
            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {
                startActivity(intent);
                overridePendingTransition(0, 0);
                finish();
            }
        }.start();
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        String getGPUinfo = gl.glGetString(GL10.GL_RENDERER).toLowerCase();
        PublicInfo.gpu = getGPUinfo;

        runOnUiThread(() -> {
            Map<String, Integer> gpuMap = new HashMap<>();
            gpuMap.put("adreno", 1);
            gpuMap.put("mali", 2);
            gpuMap.put("power", 3);

            gpuMap.forEach((key, value) -> {
                if (getGPUinfo.contains(key)) {
                    PublicInfo.gpuID = value;
                }
            });

            glSurfaceView.setVisibility(View.GONE);
        });
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
    }

    @Override
    public void onDrawFrame(GL10 gl) {
    }
}
