package com.mihanrp.sa.gui;

import android.app.Activity;
import android.view.View;
import android.widget.ProgressBar;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.mihanrp.core.R;
import com.mihanrp.sa.Util;

public class ChooseServer {

    Activity aactivity;

    private ConstraintLayout loadingBackground;
    private ProgressBar loadingProgressBar;

    public ChooseServer(Activity activity){
        aactivity = activity;

        loadingBackground = activity.findViewById(R.id.loadingBackground);
        loadingProgressBar = activity.findViewById(R.id.loadingProgressBar);
    }

    /**
     * Update the progress bar with a float percent (0-100)
     * If percent > 100, hide the progress bar
     */
    public void Update(final float percent) {
        aactivity.runOnUiThread(() -> {
            if (percent > 100f) {
                loadingBackground.setVisibility(View.GONE);
                return;
            }

            float clamped = Math.max(0f, Math.min(percent, 100f));
            int progress = Math.round(clamped);

            if (loadingBackground.getVisibility() != View.VISIBLE) {
                loadingBackground.setVisibility(View.VISIBLE);
            }

            if (loadingProgressBar.getProgress() != progress) {
                loadingProgressBar.setProgress(progress);
            }
        });
    }

    /**
     * Show the loading layout without resetting progress if already updated
     */
    public void Show() {
        aactivity.runOnUiThread(() -> {
            if (loadingProgressBar.getProgress() == 0) {
                loadingProgressBar.setProgress(0);
            }

            Util.ShowLayout(loadingBackground, false);
        });
    }
}
