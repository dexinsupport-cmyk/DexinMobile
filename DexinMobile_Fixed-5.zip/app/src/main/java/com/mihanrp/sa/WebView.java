package com.mihanrp.sa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.mihanrp.core.R;

import com.mihanrp.sa.function.BaseActivity;

public class WebView extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
    }
}