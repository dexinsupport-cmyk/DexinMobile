package com.mihanrp.sa.jsonenter;


public class DownloadData {

    public int jsonVersion;

    public String checkReleasePackageName;

    public String filesGameURL;
    public String urlMonitoring;

    public String contactTelegram;
    public String contactDiscord;
    public String contactInstagram;

}