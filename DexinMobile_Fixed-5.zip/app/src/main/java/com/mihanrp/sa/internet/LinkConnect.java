package com.mihanrp.sa.internet;

public final class LinkConnect {
   public static String URL_GET_LINK_CHECK_MODS = "https://www.gtarp.ir/client/checkmods.php";

}