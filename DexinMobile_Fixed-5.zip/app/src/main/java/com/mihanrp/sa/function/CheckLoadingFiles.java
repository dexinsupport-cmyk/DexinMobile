package com.mihanrp.sa.function;


import android.os.Build;
import android.os.Environment;

import com.mihanrp.sa.LoadingApp;
import com.mihanrp.sa.MenuActivity;
import com.mihanrp.sa.jsonenter.PublicInfo;

import org.ini4j.Wini;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import androidx.annotation.RequiresApi;

public class CheckLoadingFiles {


    public static boolean getMods(int mod_id) throws IOException {
        // check if exist
        System.out.println("MIHAIL folder #"+mod_id);
        String filePacth = Environment.getExternalStorageDirectory() + "/Android/data/" + PublicInfo.checkReleasePackageName + "/mods/"+"/"+mod_id+"/";
        File dir = new File(filePacth);
        Path path = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            path = Paths.get(filePacth);
            if (Files.exists(path)) {
                System.out.println("MIHAIL папка найдена!!!");
            }
        }
        else return false;

        File file = new File( Environment.getExternalStorageDirectory() + "/Android/data/"+PublicInfo.checkReleasePackageName+"/mods/"+mod_id+"/files/"+"/texdb/gta3.img");
        if(file.exists()){
            //  PublicInfo.GTAmodsDir =
            System.out.println("MIHAIL getMods files found");
            return true;
        }else {
            System.out.println("MIHAIL getMods files are missing");
            return false;
        }
    }

    public static int getModsID() throws IOException {
        File fileIni = new File(Environment.getExternalStorageDirectory() + "/Android/data/"+PublicInfo.checkReleasePackageName+"/files.ini");
        if(fileIni.exists()){
            Wini inid = new Wini(fileIni);
            int mod_id;
            if(inid.get("mods", "mod_select", Integer.class) != null){
                mod_id = inid.get("mods", "mod_select", Integer.class);
            } else mod_id = 0;
            return mod_id;
        }else {
            System.out.println("No file!");
            return -1;
        }
    }

    public static boolean game() throws IOException {
        PublicInfo.dirGameLocal = Environment.getExternalStorageDirectory() + "/DexinMobile/";

        File file = new File(PublicInfo.dirGameLocal+"/texdb/gta3.img");
        if(file.exists()){
            System.out.println("Михаил размер:"+getFileSizeMegaBytes(file));
        }else {
            System.out.println("Файла нет!");
            return false;
        }
        System.out.println("MIHAIL dirGameLocalType start"+PublicInfo.dirGameLocalType );
        System.out.println("MIHAIL dirGameLocal start"+PublicInfo.dirGameLocal );
        return true;
    }

    // длина файла в мегабайтах
    private static int getFileSizeMegaBytes(File file) {
        return (int) file.length()/(1024*1024);
    }


}
