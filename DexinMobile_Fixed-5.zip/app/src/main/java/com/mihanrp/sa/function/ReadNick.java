package com.mihanrp.sa.function;

import android.content.Context;
import android.os.Environment;
import android.widget.TextView;

import com.mihanrp.sa.jsonenter.PublicInfo;

import org.ini4j.Wini;

import java.io.File;
import java.io.IOException;

public class ReadNick {

    private static final String SETTINGS_PATH = Environment.getExternalStorageDirectory() + "/DexinMobile/SAMP/settings.ini";

    // نمایش نیک نیم در TextView
    public static void show(TextView textView) {
        try {
            Wini ini = new Wini(new File(SETTINGS_PATH));
            String nickName = ini.get("client", "name");
            PublicInfo.getSelectServerConnectNick = nickName;

            if (nickName != null && !nickName.equals("Nick_Name")) {
                textView.setText("خوش آمدید، " + nickName + "!");
            } else if (nickName != null) {
                textView.setText("خوش آمدید، " + nickName + "!");
            } else {
                textView.setText("خوش آمدید!");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // دریافت نیک نیم
    public static String getNick() {
        try {
            Wini ini = new Wini(new File(SETTINGS_PATH));
            return ini.get("client", "name");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // نوشتن نیک نیم در مسیر مودها
    public static void writeNickMods(int mod_int) {
        try {
            Wini ini = new Wini(new File(SETTINGS_PATH));
            String nickName = ini.get("client", "name");

            String modPath = Environment.getExternalStorageDirectory() +
                    "/Android/data/" + PublicInfo.checkReleasePackageName +
                    "/mods/" + mod_int + "/files/SAMP/settings.ini";

            Wini iniWrite = new Wini(new File(modPath));
            iniWrite.put("client", "name", nickName);
            iniWrite.store();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
