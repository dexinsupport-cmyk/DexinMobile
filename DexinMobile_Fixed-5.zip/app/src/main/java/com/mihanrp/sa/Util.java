package com.mihanrp.sa;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

public class Util {


    public static String maxWord(String par)
    {
        String[]words=par.split(" ");
        String resstring="";
        for(String word: words)
        {
            if(word.length()>resstring.length())
                resstring=word;
        }
        return(resstring);
    }

    public static void ShowLayout(View view, boolean isAnim) {
        if (view != null) {
            view.setVisibility(View.VISIBLE);
            if (isAnim) {
                fadeIn(view);
            } else {
                view.setAlpha(1.0f);
            }
        }
    }

    private static void fadeIn(View view) {
        if (view != null) {
            view.animate().setDuration(500).setListener(new AnimatorListenerAdapter() {
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                }
            }).alpha(1.0f);
        }
    }

    public static String maxWordDeleteColor(String par)
    {
        String[]words=par.split(" ");
        String resstring="";
        for(String word: words)
        {
            if(word.length()>resstring.length())
                resstring=word;
        }
        String newString =  resstring.replace("{33CC66}", "");
        String newStrings =  newString.replace("{ffffff}", "");
        resstring = newStrings;
        return(resstring);
    }

}
