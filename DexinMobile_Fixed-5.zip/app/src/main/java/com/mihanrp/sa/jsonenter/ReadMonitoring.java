package com.mihanrp.sa.jsonenter;

import com.google.gson.annotations.SerializedName;

public class ReadMonitoring {
    @SerializedName("hostname")
    public String hostname;

    @SerializedName("gamemode")
    public String gamemode;

    @SerializedName("players_online")
    public int playersOnline;

    @SerializedName("players_max")
    public int playersMax;

    @SerializedName("map")
    public String map;

    @SerializedName("weather")
    public String weather;

    @SerializedName("time")
    public String time;

    @SerializedName("version")
    public String version;

    @SerializedName("password")
    public boolean password;

    // سازنده پیش‌فرض
    public ReadMonitoring() {}
}
