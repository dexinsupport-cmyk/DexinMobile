package com.mihanrp.sa.jsonenter;


public final class PublicInfo {
    public static String VersionNameAppStatic = "ورژن فعلی: 1.3.4";

    public static int checkStartClient = 1;

    // Dexin Mobile fixed server
    public static final String SERVER_IP = "5.57.37.215";
    public static final int SERVER_PORT = 7777;

    // Direct HTTPS ZIP URL. Upload your game package here.
    public static final String GAME_DOWNLOAD_URL = "https://DexinMobile.ir/game.zip";


    public static int jsonVersion = 0;
    public static boolean successInstallApk = false;

    public static String checkReleasePackageName = "com.mihanrp.sa";

    public static String filesGameURL = GAME_DOWNLOAD_URL;

    public static String contactTelegram ;
    public static String contactInstagram;
    public static String contactDiscord;

    public static String urlMonitoring;

    public static int dirGameLocalType;
    public static String dirGameLocal = "/DexinMobile/";


    public static String checkModsURL = "";
    public static int GTAmods;

    public static String gpu;
    public static int gpuID;


    public static String getSelectServerConnectNick = "none";
    public static int goggleCodeInit = 0;
    public static String goggleCode = "none";
}