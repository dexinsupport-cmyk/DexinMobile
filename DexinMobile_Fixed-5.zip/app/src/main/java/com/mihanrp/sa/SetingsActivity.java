package com.mihanrp.sa;

import android.content.Intent;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;


import com.mihanrp.sa.function.MainDialogFragment;
import com.mihanrp.sa.jsonenter.PublicInfo;
import com.mihanrp.core.R;

import org.ini4j.Wini;

import java.io.File;
import java.io.IOException;

import com.mihanrp.sa.function.BaseActivity;

public class SetingsActivity<MyTask> extends BaseActivity {

    private final File iniFile = new File(PublicInfo.dirGameLocal + "/SAMP/settings.ini");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setings);

        // --- Toggle Settings ---
        setupToggle(R.id.toggleFPS, "fpscounter", 0);
        setupToggle(R.id.toggleGraphics, "skybox", 0);

        // --- SeekBar Settings ---
        setupSeekBar(R.id.maxFPSCounter, R.id.maxFPSSeekBar, "fps", 90, 30);
        setupSeekBar(R.id.chatStringsCounter, R.id.chatStringsSeekBar, "ChatMaxMessages", 10, 4);

        // --- Reinstall Game ---
        findViewById(R.id.dialog_settings_button_reset).setOnClickListener(v ->
                new MainDialogFragment(
                        "نصب مجدد بازی",
                        "آیا واقعاً می‌خواهید بازی را دوباره نصب کنید؟",
                        "خیر",
                        "بله",
                        null,
                        () -> {
                            startActivity(new Intent(this, LoadingGPU.class));
                            overridePendingTransition(0, 0);
                        }
                ).show(getSupportFragmentManager(), "mainDialog")
        );

        // --- Bottom Menu ---
        findViewById(R.id.imageDownLeftMenu).setOnClickListener(v -> restartActivity());
        findViewById(R.id.imageDownCenterMenu).setOnClickListener(v -> startMenuActivity(1));
        findViewById(R.id.imageDownCenterMenu).setOnLongClickListener(v -> {
            startMenuActivity(2);
            return false;
        });
        findViewById(R.id.imageDownRightMenu).setOnClickListener(v -> startActivity(new Intent(this, MenuActivity.class)));
    }

    // --- Toggle Helper ---
    private void setupToggle(int toggleId, String key, int defaultValue) {
        ToggleButton toggle = findViewById(toggleId);
        toggle.setChecked(readIni(key, defaultValue) == 1);
        toggle.setOnCheckedChangeListener((buttonView, isChecked) -> writeIni(key, isChecked ? 1 : 0));
    }

    // --- SeekBar Helper ---
    private void setupSeekBar(int tvId, int sbId, String key, int defaultValue, int min) {
        TextView tv = findViewById(tvId);
        SeekBar sb = findViewById(sbId);
        int value = readIni(key, defaultValue);
        tv.setText(formatNumber(value));
        sb.setProgress(value);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress < min) progress = min;
                tv.setText(formatNumber(progress));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                int progress = Math.max(seekBar.getProgress(), min);
                tv.setText(formatNumber(progress));
                writeIni(key, progress);
            }
        });
    }

    // --- INI Read/Write ---
    private int readIni(String key, int defaultValue) {
        try {
            Wini ini = new Wini(iniFile);
            Integer value = ini.get("gui", key, Integer.class);
            return value != null ? value : defaultValue;
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            return defaultValue;
        }
    }

    private void writeIni(String key, int value) {
        try {
            Wini ini = new Wini(iniFile);
            ini.put("gui", key, value);
            ini.store();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "خطا در ذخیره تنظیمات " + key, Toast.LENGTH_SHORT).show();
        }
    }

    // --- Bottom Menu Actions ---
    private void restartActivity() {
        startActivity(new Intent(this, SetingsActivity.class));
        overridePendingTransition(0, 0);
    }

    private void startMenuActivity(int typeStart) {
        Intent intent = new Intent(this, MenuActivity.class);
        intent.putExtra("startGame", true);
        intent.putExtra("typeStart", typeStart);
        startActivity(intent);
        overridePendingTransition(0, 0);
    }

    // --- Number Formatter ---
    private String formatNumber(int number) {
        if (number < 10) return "  " + number;
        if (number < 100) return " " + number;
        return String.valueOf(number);
    }
}
