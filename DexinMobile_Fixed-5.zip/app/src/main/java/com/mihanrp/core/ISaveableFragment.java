package com.mihanrp.core;

public interface ISaveableFragment {
    public void save();
    public void getValues();
}
