package com.mihanrp.core;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.Toast;

import com.mihanrp.sa.jsonenter.PublicInfo;
import com.wardrumstudios.utils.WarMedia;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

public class GTASA extends WarMedia {
    public static GTASA gtasaSelf = null;
    static String vmVersion;
    private boolean once = false;

    {
        vmVersion = null;
        System.out.println("**** Loading SO's");
        try
        {
            vmVersion = System.getProperty("java.vm.version");
            System.out.println("vmVersion " + vmVersion);
            System.loadLibrary("ImmEmulatorJ");
        } catch (ExceptionInInitializerError | UnsatisfiedLinkError e) {
        }

        String libPath = System.getProperty("java.library.path");
        System.out.println("MIHANRP libPath:" + libPath);

        System.loadLibrary("GTASA");
        //    System.load
        // System.loadLibrary("samp");
        //   System.load("/data/data/com.mihanrp.sa/lib/libsamp.so");
        try
        {
            vmVersion = System.getProperty("java.vm.version");
            System.out.println("vmVersion " + vmVersion);
            System.loadLibrary("ImmEmulatorJ");

            if(PublicInfo.checkStartClient == 1){
                System.loadLibrary("samp");
                System.out.println("MIHANRP Stable client launched");
            }
            else {
                //System.load("/data/data/com.mihanrp.sa/lib/libsamp_new.so");

                //System.loadLibrary("samp_new");
                System.loadLibrary("samp");

                System.out.println("MIHANRP Test client launched");
                //System.loadLibrary("samp");
                // System.load(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/libsamp_new.so");
            }
        } catch (ExceptionInInitializerError | UnsatisfiedLinkError e) {

            //  Toast.makeText(this, "Ошибка:"+e, Toast.LENGTH_LONG).show();
        }


//        System.loadLibrary(Environment.getExternalStorageDirectory() + "/Android/data/com.mihanrp.sa/libsamp.so");

        //setClientLauncherVersion(2);
    }

    public static void staticEnterSocialClub()
    {
        gtasaSelf.EnterSocialClub();
    }

    public static void staticExitSocialClub() {
        gtasaSelf.ExitSocialClub();
    }

    public void AfterDownloadFunction() {

    }

    public void EnterSocialClub() {

    }

    public void ExitSocialClub() {

    }

    public boolean ServiceAppCommand(String str, String str2)
    {
        return false;
    }

    public int ServiceAppCommandValue(String str, String str2)
    {
        return 0;
    }

    public native void main();

    public void onActivityResult(int i, int i2, Intent intent)
    {
        super.onActivityResult(i, i2, intent);
    }

    public void onConfigurationChanged(Configuration configuration)
    {
        super.onConfigurationChanged(configuration);
    }

    private native void setClientIp(byte[] ip);
    private native void setClientPort(int port);
    private native void setClientLauncherVersion(int version);
    private native void setClientModpackVersion(int version);
    private static native void setClientUuid(byte[] uuid);
    private native void setClientMajorVersion(int version);
    private native void setClientMinorVersion(int version);
    private native boolean isAPAKAndLibSame(int gameEdition);


    public static void setUUID(String uid){
        try {
            byte[] dataBytes = uid.getBytes("windows-1251");
            setClientUuid(dataBytes);
            System.out.println("MIHANRP setUUID"+uid);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            System.out.println("MIHANRP code failed"+uid);

        }
    }

    public void onCreate(Bundle bundle)
    {
        System.out.println("Dexin Mobile GTASA onCreate");
        gtasaSelf = this;
        // Always join the one configured Dexin Mobile server.
        try {
            setClientIp(PublicInfo.SERVER_IP.getBytes(StandardCharsets.US_ASCII));
            setClientPort(PublicInfo.SERVER_PORT);
            setClientLauncherVersion(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        wantsMultitouch = true;
        wantsAccelerometer = true;
        super.onCreate(bundle);
    }

    public void onDestroy()
    {
        System.out.println("GTASA onDestroy");
        super.onDestroy();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent)
    {
        return super.onKeyDown(i, keyEvent);
    }

    public void onPause()
    {
        System.out.println("GTASA onPause");
        super.onPause();
    }

    public void onRestart()
    {
        System.out.println("GTASA onRestart");
        super.onRestart();
    }

    public void onResume()
    {
        System.out.println("GTASA onResume");
        super.onResume();
    }

    public void onStart()
    {
        System.out.println("GTASA onStart");
        super.onStart();
    }

    public void onStop()
    {
        System.out.println("GTASA onStop");

        super.onStop();
    }

    public native void setCurrentScreenSize(int i, int i2);
}