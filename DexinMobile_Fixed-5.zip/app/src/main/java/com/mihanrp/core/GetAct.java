package com.mihanrp.core;

public class GetAct {
}
