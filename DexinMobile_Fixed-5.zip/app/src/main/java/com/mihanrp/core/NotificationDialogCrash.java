package com.mihanrp.core;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.mihanrp.sa.MenuActivity;
import com.mihanrp.sa.SetingsActivity;

import androidx.core.internal.view.SupportMenu;
import androidx.fragment.app.DialogFragment;

public class NotificationDialogCrash extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage("شما فایل های لازم برای اجرای بازی را ندارید.\nبه بخش «تنظیمات» بروید و روی دکمه «نصب مجدد بازی» کلیک کنید.\nهنگام نصب مجدد، بازی را مینیمایز نکنید.")
                .setPositiveButton("به تنظیمات بروید", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent intent = new Intent(getActivity(), SetingsActivity.class);
                        startActivity(intent);
                    }
                });
        return builder.create();
    }
}
