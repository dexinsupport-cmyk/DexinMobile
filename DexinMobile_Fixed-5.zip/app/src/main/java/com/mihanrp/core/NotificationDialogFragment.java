package com.mihanrp.core;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.DialogFragment;
public class NotificationDialogFragment extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        TextView messageView = new TextView(getActivity());
        messageView.setText("برای استفاده از صفحه بی‌نهایت، باید دوباره وارد بازی شوید.");
        messageView.setPadding(50, 40, 50, 40);
        messageView.setTextSize(16);

        Typeface typeface = ResourcesCompat.getFont(getActivity(), R.font.iranyekanregular);
        messageView.setTypeface(typeface);

        builder.setView(messageView)
                .setPositiveButton("بستن", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

        return builder.create();
    }
}

