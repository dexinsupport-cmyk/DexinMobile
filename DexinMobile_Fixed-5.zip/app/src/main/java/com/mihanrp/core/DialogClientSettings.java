package com.mihanrp.core;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.DialogFragment;
import androidx.viewpager.widget.ViewPager;


import com.mihanrp.core.DialogClientSettingsAdapter;
import com.mihanrp.core.ISaveableFragment;
import com.mihanrp.core.R;
import com.google.android.material.tabs.TabLayout;
import com.nvidia.devtech.NvEventQueueActivity;


public class DialogClientSettings extends DialogFragment {
    TabLayout tabLayout;
    ViewPager viewPager;

    static final int mSettingsHudCountOffsetLeft = 1;
    static final int mSettingsHudCount = 10;
    static final int mSettingsHudFPSStart = 10;
    static final int mSettingsHudFPSEnd = 12;

    static final int mSettingsWeaponsStart = 12;
    static final int mSettingsWeaponsEnd = 14;

    static final int mSettingsComonStart = 14;
    static final int mSettingsComonEnd = 16;
    NvEventQueueActivity mContext = null;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState)
    {
        View rootview = inflater.inflate(R.layout.dialog_settings,null,false);
        tabLayout = (TabLayout) rootview.findViewById(R.id.tabLayout);
        viewPager = (ViewPager) rootview.findViewById(R.id.masterViewPager);
        final DialogClientSettingsAdapter adapter = new DialogClientSettingsAdapter(getChildFragmentManager(), 0);
        adapter.addFragment("مبانی",DialogClientSettingsCommonFragment.createInstance("common"));
        adapter.addFragment("رنگ ها", DialogClientSettingsColorFragment.createInstance("colors"));
        adapter.addFragment("شخص اول", DialogClientSettingsFPSFragment.createInstance("fps").setRoot((ViewGroup)rootview.findViewById(R.id.ll_settings_root)));
        adapter.addFragment("هاد", DialogClientSettingsHUDFragment.createInstance("hud").setRoot((ViewGroup)rootview.findViewById(R.id.ll_settings_root)));
        adapter.addFragment("اصلحه", DialogClientSettingsWeaponsFragment.createInstance("weapons").setRoot((ViewGroup)rootview.findViewById(R.id.ll_settings_root)));
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        // بارگذاری فونت
        Typeface persianFont = ResourcesCompat.getFont(getContext(), R.font.iranyekanregular);

        // ست کردن فونت روی TabLayout
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            if (tab != null) {
                TextView tabTextView = new TextView(getContext());
                tabTextView.setText(tab.getText());
                tabTextView.setTypeface(persianFont);
                tabTextView.setTextSize(16); // اندازه فونت دلخواه
                tabTextView.setTextColor(Color.WHITE); // رنگ متن دلخواه
                tab.setCustomView(tabTextView);
            }
        }

        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        getDialog().getWindow().setDimAmount(.0f);

        mContext = (NvEventQueueActivity) getActivity();

        rootview.findViewById(R.id.dialog_settings_button_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mContext.onSettingsWindowSave();
                getDialog().dismiss();
            }
        });

        rootview.findViewById(R.id.dialog_settings_button_reset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mContext.onSettingsWindowDefaults(tabLayout.getSelectedTabPosition() + 1);

                ISaveableFragment fragment = (ISaveableFragment) adapter.getItem(tabLayout.getSelectedTabPosition());
                fragment.getValues();

                mContext.onSettingsWindowSave();
            }
        });

        setCancelable(false);

        return rootview;
    }
}
